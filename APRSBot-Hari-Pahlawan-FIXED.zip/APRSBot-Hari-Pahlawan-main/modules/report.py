"""Compatibility wrapper for the report command."""
from report import handle_command

__all__ = ["handle_command"]
