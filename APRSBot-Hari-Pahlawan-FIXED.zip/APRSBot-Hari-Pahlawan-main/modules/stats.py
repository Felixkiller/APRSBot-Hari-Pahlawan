"""Compatibility wrapper for the stats command."""
from stats import handle_command

__all__ = ["handle_command"]
