"""Compatibility wrapper for the help command."""
from help import handle_command

__all__ = ["handle_command"]
