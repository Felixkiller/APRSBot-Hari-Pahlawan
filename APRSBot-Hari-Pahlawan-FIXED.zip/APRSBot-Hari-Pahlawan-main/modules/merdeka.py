"""Compatibility wrapper for the merdeka command."""
from merdeka import handle_command

__all__ = ["handle_command"]
