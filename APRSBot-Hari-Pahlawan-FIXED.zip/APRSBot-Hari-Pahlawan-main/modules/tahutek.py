"""Compatibility wrapper for the tahutek command."""
from tahutek import handle_command

__all__ = ["handle_command"]
