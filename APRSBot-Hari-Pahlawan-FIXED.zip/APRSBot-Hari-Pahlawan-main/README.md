# APRS Bot Hari Pahlawan — UKDC

Bot APRS-IS untuk membalas pesan `MERDEKA` dengan QSL Card Hari Pahlawan yang dipersonalisasi menggunakan callsign pengirim.

## Perbaikan pada paket ini

- Menambahkan package `modules/` yang sebelumnya tidak tersedia, sehingga dynamic command loader dapat menemukan lima command.
- Memindahkan/menyalin aset gambar ke `modules/images/`, sesuai path konfigurasi.
- Menetapkan callsign default bot ke `YC3ADM-10`.
- Menghapus passcode APRS yang tertanam di source code. Passcode wajib diberikan melalui environment variable.
- Menambahkan pengujian alur pembuatan QSL `MERDEKA` tanpa koneksi APRS-IS atau upload Catbox.

## Persiapan Windows

Gunakan Python 3.10 atau lebih baru.

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
```

Atur passcode APRS-IS pada terminal PowerShell yang sama. Jangan masukkan passcode ke file source atau commit ke GitHub:

```powershell
$env:APRS_CALLSIGN = "YC3ADM-10"
$env:APRS_PASSCODE = "ISI_PASSCODE_APRS_MILIK_BOT"
```

Jalankan pengujian lokal (tidak menghubungi APRS-IS):

```powershell
python test_bot.py
```

Jalankan bot:

```powershell
python main.py
```

## Command APRS

Kirim pesan APRS ke `YC3ADM-10`:

- `MERDEKA` — membuat QSL Card Hari Pahlawan dengan callsign pengirim dan membalas pesan.
- `help` — daftar command.
- `stats` — ringkasan statistik.
- `report` — membuat laporan statistik.
- `tahutek` — command event Tahu Tek lama.

## Struktur penting

```text
modules/
  __init__.py
  merdeka.py
  help.py
  stats.py
  report.py
  tahutek.py
  images/
    qsl_hari_pahlawan_template.jpg
    ukdc_logo.png
    tahu_tek.jpg
```

## Keamanan

Jika passcode APRS sebelumnya pernah dipublikasikan di repository, reset/ganti passcode tersebut melalui sumber APRS yang berwenang. Jangan gunakan kembali passcode yang telah terekspos.
